const Migrations = artifacts.require("Treatment.sol");

module.exports = function (deployer) {
  deployer.deploy(Migrations);
};
